import "../css/style.scss"
import "./run_trigger.js"
import "./form_submit.js"
